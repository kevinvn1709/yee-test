export default  {
    widthContainer: '90%',
    widthContainerFull: '100%',
    primaryColor: '#157AFB',
    primaryTextColor: 'white',
    primaryFontSize: 12,
    inputHeight: 36,
}