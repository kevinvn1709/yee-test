import React from 'react';
import {View, Text, TextInput, ListView} from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import {Actions} from 'react-native-router-flux';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import * as SearchAction from '../../actions/search';
import * as FindAction from '../../actions/find';
import AppStyles from '../../styles/app';
import SearchBar from '../../components/widgets/SearchBar';
import ListViewStopPoints from '../../components/listview/ListViewStopPoints';

var styles = EStyleSheet.create({
    searchBar: {
        flex: 1,
        flexDirection: 'row'
    },
    listStopPoint: {
        flex: 5
    }
})
class Search extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showLoading: false,
        }
    }

    render() {
        console.log(this.props.payload);
        return (
            <View style={AppStyles.screen}>
                <View style={AppStyles.wrapper}>
                    <View style={AppStyles.container}>
                        <View style={styles.searchBar}>
                            <SearchBar
                                onSearchPress={this.onSearchPress.bind(this)}
                            />
                        </View>
                        <View style={styles.listStopPoint}>
                            <ListViewStopPoints
                                onItemPress={this.onItemPress.bind(this)}
                                showLoading={this.props.payload.showLoading}
                                dataSource={this.props.payload.search}
                            />
                        </View>
                    </View>
                </View>
            </View>
        )
    }

    onItemPress(value) {
        console.log(value);
    }

    onSearchPress(value) {
        this.setState({showLoading: true});
        //this.props.search.searchBusNumber(value);
        this.props.find.findBusNumber(value);
    }
}


function mapStateToProps(rootState) {
    return {
        payload: rootState.search,
    }
}

function mapDispatchToProps(dispatch) {
    return {
        search: bindActionCreators(SearchAction, dispatch),
        find: bindActionCreators(FindAction, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Search);