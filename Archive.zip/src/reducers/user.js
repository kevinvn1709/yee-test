import * as types from '../configs/actions';
const INITIAL_STATE = {
    username: "trinm",
    title: "developer",
};

export default function (state = INITIAL_STATE, action) {
    switch (action.type) {
        default:
            return state;
    }
}