import * as types from '../configs/actions';
const INITIAL_STATE = {
    showLoading: false,
};

export default function (state = INITIAL_STATE, action) {
    switch (action.type) {
        case types.SEARCH_BUS_NUMBER:
            if(action.payload.stopPointSequences){
                return {...state, search: action.payload.stopPointSequences[0].stopPoint};
            }else{
                return {...state, search: []};
            }
        case types.SHOW_LOADING:
            return {...state, showLoading: true};
        case types.HIDE_LOADING:
            return {...state, showLoading: false};
        default:
            return state;
    }
}