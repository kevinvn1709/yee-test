import {combineReducers} from 'redux';
import SearchReducer from '../reducers/search';
import UserReducer from '../reducers/user';

const rootReducer = combineReducers({
    search: SearchReducer,
    user: UserReducer,
});

export default rootReducer;
