import keyMirror from "keymirror";

module.exports = keyMirror({
    SHOW_LOADING: null,
    HIDE_LOADING: null,
    SEARCH_BUS_NUMBER: null,
});