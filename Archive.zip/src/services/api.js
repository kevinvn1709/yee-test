const API_SERACH_BUS_NUMBER = 'https://api.tfl.gov.uk/line/{busNumber}/route/sequence/outbound';

module.exports = {
    searchBusNumber: function (busNumber) {
        return api_search_bus(busNumber);
    },
}

function api_search_bus(busNumber) {
    try {
        var url = API_SERACH_BUS_NUMBER.replace('{busNumber}', busNumber);
        return fetch(url).then((response) => response.json());
    } catch (error) {
        console.error(error);
    }
}