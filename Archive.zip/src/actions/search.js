import * as types from '../configs/actions';
import API from '../services/api';

export function searchBusNumber(busNumber) {
    return dispatch => {
        dispatch({
            type: types.SHOW_LOADING,
        });
        API.searchBusNumber(busNumber).then(res => {
            dispatch({
                type: types.SEARCH_BUS_NUMBER,
                payload: res,
            })
            dispatch({
                type: types.HIDE_LOADING,
            });
        })
    }
}

export function searchLineNumber(busNumber) {
    return dispatch => {
        dispatch({
            type: types.SHOW_LOADING,
        });
        API.searchBusNumber(busNumber).then(res => {
            dispatch({
                type: types.SEARCH_BUS_NUMBER,
                payload: res,
            })
            dispatch({
                type: types.HIDE_LOADING,
            });
        })
    }
}