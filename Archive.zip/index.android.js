import React, { AppRegistry } from 'react-native';
import App from './src/app';

AppRegistry.registerComponent('YeeTestGit', () => App);